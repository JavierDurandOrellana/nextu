import React from 'react';

class App extends React.Component{
    render(){
        return(
            <div>
                Hola React
              </div>
            );
        }
      }

export default App;
